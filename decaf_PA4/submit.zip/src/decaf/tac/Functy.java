package decaf.tac;

import decaf.symbol.Function;

public class Functy {
	public Label label;

	public Tac paramMemo;

	public Tac head;

	public Tac tail;

	public Function sym;
}
